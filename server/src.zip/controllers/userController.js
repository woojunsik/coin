exports.getUser = (req, res) => {
  res.json({ message: '유저 정보 반환 예시' });
};

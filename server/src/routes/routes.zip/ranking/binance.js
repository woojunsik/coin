const express = require('express');
const router = express.Router();
const Wallet = require('../../models/Wallet');

router.get('/', async (req, res) => {
  try {
    const wallets = await Wallet.find({ exchange: 'binance' })
      .sort({ totalKRW: -1 })
      .populate('user', 'nickname profile');

    const ranked = wallets.map((wallet, index) => ({
      rank: index + 1,
      nickname: wallet.user?.nickname || '알 수 없음',
      profile: wallet.user?.profile || '',
      totalKRW: wallet.totalKRW,
      assets: wallet.assets,
    }));

    res.json(ranked);
  } catch (err) {
    console.error('[🔴 Binance 랭킹 오류]', err.message);
    res.status(500).json({ message: '랭킹 조회 실패', error: err.message });
  }
});

module.exports = router;

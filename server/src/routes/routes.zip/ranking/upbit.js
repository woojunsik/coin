const express = require('express');
const router = express.Router();
const Wallet = require('../../models/Wallet');
const User = require('../../models/User');

// ✅ 업비트 전용 랭킹 API (Upbit 거래소 랭킹)
router.get('/', async (req, res) => {
  try {
    const upbitWallets = await Wallet.find({ exchange: 'upbit' })
      .sort({ totalKRW: -1 })
      .populate('user', 'nickname profile');

    const ranked = upbitWallets.map((wallet, index) => ({
      rank: index + 1,
      nickname: wallet.user?.nickname || '알 수 없음',
      profile: wallet.user?.profile || '',
      totalKRW: wallet.totalKRW,
      assets: wallet.assets,
    }));

    res.json(ranked);
  } catch (err) {
    console.error('[업비트 랭킹 오류]', err);
    res.status(500).json({ message: '업비트 랭킹 불러오기 실패', error: err.message });
  }
});

module.exports = router;

const express = require("express");
const router = express.Router();
const Wallet = require("../../models/Wallet");
const User = require("../../models/User");

// ✅ 전체 지갑 자산 랭킹 API (거래소 통합 기준)
router.get("/", async (req, res) => {
  try {
    // 🔹 모든 지갑을 유저 정보와 함께 조회
    const wallets = await Wallet.find().populate("user", "nickname profile");

    const userMap = new Map();

    // 🔹 동일 유저의 여러 지갑 자산을 합산
    wallets.forEach((wallet) => {
      if (!wallet.user) return;

      const uid = wallet.user._id.toString();
      if (!userMap.has(uid)) {
        userMap.set(uid, {
          user: wallet.user,
          totalKRW: wallet.totalKRW || 0,
          assets: [...(wallet.assets || [])],
        });
      } else {
        const prev = userMap.get(uid);
        prev.totalKRW += Math.floor(wallet.totalKRW || 0);
        prev.assets.push(...(wallet.assets || []));
      }
    });

    // 🔹 보유 자산 총액 기준으로 정렬
    const ranked = Array.from(userMap.values()).sort(
      (a, b) => b.totalKRW - a.totalKRW
    );

    // 🔹 응답 포맷 정리
    const formatted = ranked.map((entry, index) => {
      console.log("[💰 합산된 totalKRW]", entry.totalKRW); // ✅ 여기에 찍어보기
      return {
        userId: entry.user._id,
        rank: index + 1,
        nickname: entry.user?.nickname || "익명",
        profile: entry.user?.profile || "",
        totalKRW: entry.totalKRW,
        assets: entry.assets,
      };
    });

    res.json(formatted);
  } catch (err) {
    console.error("[랭킹 전체 실패]", err);
    res.status(500).json({ message: "서버 오류", error: err.message });
  }
});

module.exports = router;

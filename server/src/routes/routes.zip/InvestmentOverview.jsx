import React, { useState, useEffect, useCallback } from "react";
import axios from "axios";
import InvestmentChart from "./InvestmentChart";
import AssetTable from "./AssetTable";
import AssetPieChart from "./AssetPieChart";
import CronCountdown from "./CronCountdown";
import SummaryCard from "./SummaryCard";
import ExchangeTabs from "./ExchangeTabs";
import RankBox from "./RankBox";
import ChangeBox from "./ChangeBox";

const InvestmentOverview = ({ data, onRefresh }) => {
  const [activeExchange, setActiveExchange] = useState("all");
  const [dailyAssets, setDailyAssets] = useState([]);
  const [cron, setCron] = useState(null);
  const [rank, setRank] = useState(null);
  const [lastKnownUpdate, setLastKnownUpdate] = useState(data?.lastUpdatedAt);

  const fetchCronSettings = useCallback(async () => {
    try {
      const res = await axios.get("/api/settings");
      setCron(res.data);
    } catch (err) {
      console.error("CRON 설정 로드 실패", err);
    }
  }, []);

  const fetchRank = useCallback(async () => {
    try {
      const rankPath =
        activeExchange === "all"
          ? "/api/ranking/all"
          : `/api/ranking/${activeExchange}`;
      const res = await axios.get(rankPath);

      if (Array.isArray(res.data)) {
        const myRank =
          res.data.findIndex(
            (r) => r.userId?.toString?.() === data.userId?.toString?.()
          ) + 1;
        setRank(myRank > 0 ? myRank : null);
      } else {
        console.error("랭킹 데이터가 배열이 아님:", res.data);
      }
    } catch (err) {
      console.error("랭킹 불러오기 실패:", err);
    }
  }, [data?.userId, activeExchange]);

  const checkAndRefresh = useCallback(async () => {
    try {
      const res = await axios.get(`/api/investment/${data.userId}`);
      const serverUpdatedAt = res.data.lastUpdatedAt;
      if (serverUpdatedAt !== lastKnownUpdate) {
        setLastKnownUpdate(serverUpdatedAt);
        onRefresh();
      } else {
        setTimeout(checkAndRefresh, 5000);
      }
    } catch (err) {
      console.error("서버 갱신 확인 실패:", err);
    }
  }, [data?.userId, lastKnownUpdate, onRefresh]);

  useEffect(() => {
    fetchCronSettings();
  }, [fetchCronSettings]);

  useEffect(() => {
    if (data?.lastUpdatedAt) setLastKnownUpdate(data.lastUpdatedAt);
  }, [data?.lastUpdatedAt]);

  useEffect(() => {
    if (data?.userId) fetchRank();
  }, [data?.userId, fetchRank]);

  useEffect(() => {
    if (!data) return;
    const assets =
      activeExchange === "all"
        ? data.dailyAssets
        : data.dailyAssetsByExchange?.[activeExchange] || [];
    setDailyAssets(assets);
  }, [data, activeExchange]);

  useEffect(() => {
    console.log("🔁 렌더링 직전 데이터 확인:", dailyAssets);
  }, [dailyAssets]);

  if (!data || data.coins.length === 0) {
    return (
      <div className="text-center text-gray-500 py-10 text-sm">
        거래소 API 등록하여 나의 자산 순위와 자산변화를 확인하세요
      </div>
    );
  }

  const connectedExchanges = [
    ...new Set(data.coins.map((c) => c.exchange).filter(Boolean)),
  ];
  const allExchanges = Object.keys(data.dailyAssetsByExchange || {});
  const mergedExchanges = [
    "all",
    ...new Set([...connectedExchanges, ...allExchanges]),
  ];

  const filteredCoins =
    activeExchange === "all"
      ? data.coins
      : data.coins.filter((coin) => coin.exchange === activeExchange);
  const totalAssets =
    activeExchange === "all"
      ? data.totalAssets || 0
      : filteredCoins.reduce((sum, coin) => sum + (coin.krw || 0), 0);

  const last = dailyAssets.at(-2)?.totalKRW || 0;
  const today = dailyAssets.at(-1)?.totalKRW || 0;
  const diff = today - last;
  const percent = last > 0 ? ((diff / last) * 100).toFixed(2) : "0.00";

  if (totalAssets === 0) {
    return (
      <div className="text-center text-sm text-gray-500 py-10">
        현재 등록된 거래소에 보유 자산이 없습니다.
        <br />
        거래소 자산을 보유하거나 거래 내역이 생기면 정보가 표시됩니다.
      </div>
    );
  }

  return (
    <div className="bg-white shadow-xl rounded-3xl p-8 space-y-10 border border-gray-100">
      <ExchangeTabs
        mergedExchanges={mergedExchanges}
        activeExchange={activeExchange}
        setActiveExchange={setActiveExchange}
        connectedExchanges={connectedExchanges}
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <SummaryCard
          title="총 자산"
          value={`₩ ${totalAssets.toLocaleString()}`}
          highlight
        />
        <SummaryCard
          title="연결된 거래소"
          value={`${connectedExchanges.length}개`}
        />
        <SummaryCard title="등록된 코인" value={`${filteredCoins.length}개`} />
      </div>

      <RankBox rank={rank} activeExchange={activeExchange} />
      <ChangeBox diff={diff} percent={percent} />

      <AssetTable
        coins={filteredCoins}
        exchange={activeExchange}
        totalAssets={totalAssets}
        diff={diff}
        percent={percent}
        showChange={last > 0 || today > 0}
        hideChange={totalAssets === 0 && today === 0}
      />

      <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
        <AssetPieChart coins={filteredCoins} />
      </div>

      <CronCountdown cron={cron} onCountdownEnd={checkAndRefresh} />

      <div className="text-xs text-gray-400 text-center mt-2">
        ⏳ 다음 자산 갱신 후 전체 데이터가 새로 반영됩니다.
      </div>

      <div>
        <h4 className="text-md font-semibold mb-3 text-gray-800">
          📈 자산 변화 추이
        </h4>
        {dailyAssets.length === 0 ? (
          <div className="text-center text-sm text-gray-400 py-10">
            📉 아직 자산 변화 기록이 없습니다.
          </div>
        ) : (
          <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
            <InvestmentChart data={dailyAssets} />
          </div>
        )}
      </div>
    </div>
  );
};

export default InvestmentOverview;

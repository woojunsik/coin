export default function BinanceGuide() {
  return (
    <div>
      {/* 가이드 내용 */}
      <h3>바이낸스 API 발급 가이드</h3>
      <img src="/images/guides/binance-step1.png" alt="step1" />
    </div>
  );
}